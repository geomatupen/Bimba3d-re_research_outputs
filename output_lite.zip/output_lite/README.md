# Bimba3D-re Research Outputs Lite

This lightweight folder contains only CSV, JSON, Markdown, and text files copied from the full `outputs` folder. Images, preview renders, and heavy model binary files are intentionally excluded so the folder can be zipped and shared more easily.

Main code repository: [geomatupen/bimba3d-re](https://github.com/geomatupen/bimba3d-re)

Primary report tables:

- `1. ridge_regression/final_ridge_test_metrics_multipliers_descriptors.csv`
- `2. mlp/final_mlp_test_metrics_multipliers_descriptors.csv`

The copied source pipeline snapshots may include historical runs and are kept only for traceability.
